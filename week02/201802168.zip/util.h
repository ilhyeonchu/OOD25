#ifndef _UTIL_H_
#define _UTIL_H_

#include <assert.h>

#include <iostream>

class Util {
 public:
  int Add(int num1, int num2);
  int Sub(int num1, int num2);
  int Mul(int num1, int num2);
  int Div(int num1, int num2);
};

#endif  //  _UTIL_H_

#include <iostream>

#include "float_accumulator.h"
#include "int_accumulator.h"

int main() { return 0; }

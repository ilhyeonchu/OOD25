#include <stdio.h>

#include "list.h"
#include "queue.h"
#include "stack.h"
#include "vector.h"

int main() { return 0; }
